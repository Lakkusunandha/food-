import { Routes, Route } from 'react-router-dom'
import Navbar from './components/Navbar'
import Home from './pages/Home'
import Login from './pages/Login'
import Register from './pages/Register'
import DonorDashboard from './pages/DonorDashboard'
import PostDonation from './pages/PostDonation'
import AvailableDonations from './pages/AvailableDonations'
import MyDonations from './pages/MyDonations'
import MyClaims from './pages/MyClaims'
import AdminDashboard from './pages/AdminDashboard'

export default function App() {
  return (
    <>
      <Navbar />
      <main className="page-shell">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/donor" element={<DonorDashboard />} />
          <Route path="/post-donation" element={<PostDonation />} />
          <Route path="/donations" element={<AvailableDonations />} />
          <Route path="/my-donations" element={<MyDonations />} />
          <Route path="/my-claims" element={<MyClaims />} />
          <Route path="/admin" element={<AdminDashboard />} />
        </Routes>
      </main>
      <footer className="footer">
        <p>FoodShare • Share Food. Reduce Waste. Feed People.</p>
      </footer>
    </>
  )
}
