import { Link } from 'react-router-dom'

export default function Home() {
  return (
    <div>
      <section className="hero">
        <div className="hero-copy">
          <span className="eyebrow">🌱 FOOD • PEOPLE • PLANET</span>
          <h1>Share Food.<br /><span>Reduce Waste.</span><br />Feed People.</h1>
          <p>
            FoodShare connects surplus food from restaurants and communities
            with NGOs and people who need it.
          </p>
          <div className="hero-actions">
            <Link to="/post-donation" className="btn btn-primary">Donate Food</Link>
            <Link to="/donations" className="btn btn-outline">Find Food</Link>
          </div>
        </div>

        <div className="hero-visual">
          <div className="food-orbit">🍲</div>
          <div className="floating-card card-a">♻️ Less food waste</div>
          <div className="floating-card card-b">🤝 More communities helped</div>
        </div>
      </section>

      <section className="section">
        <div className="section-heading">
          <span className="eyebrow">SIMPLE PROCESS</span>
          <h2>How FoodShare Works</h2>
        </div>
        <div className="steps-grid">
          <div className="step-card"><span>🍱</span><h3>Donate</h3><p>Post safe surplus food with quantity and pickup details.</p></div>
          <div className="step-card"><span>🤝</span><h3>Claim</h3><p>NGOs discover available donations and claim what they need.</p></div>
          <div className="step-card"><span>🚚</span><h3>Pickup</h3><p>Coordinate pickup and mark the donation through completion.</p></div>
        </div>
      </section>

      <section className="impact-banner">
        <div><strong>250+</strong><span>Food units saved</span></div>
        <div><strong>500+</strong><span>People helped</span></div>
        <div><strong>85+</strong><span>Donations posted</span></div>
        <div><strong>30+</strong><span>Completed pickups</span></div>
      </section>
    </div>
  )
}
