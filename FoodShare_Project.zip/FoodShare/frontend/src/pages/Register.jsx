import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import API from '../api'

export default function Register() {
  const navigate = useNavigate()
  const [form, setForm] = useState({
    name: '', email: '', password: '', phone: '', city: '', role: 'DONOR'
  })
  const [message, setMessage] = useState('')

  const update = (key, value) => setForm({ ...form, [key]: value })

  const submit = async (e) => {
    e.preventDefault()
    setMessage('')

    try {
      await API.post('/auth/register', form)
      setMessage('Registration successful. Please login.')
      setTimeout(() => navigate('/login'), 700)
    } catch {
      // Frontend fallback for demo/testing before backend is available.
      setMessage('Registration captured for frontend demo. Connect Spring Boot to persist it.')
    }
  }

  return (
    <div className="auth-wrap">
      <form className="auth-card wide" onSubmit={submit}>
        <span className="auth-icon">🌱</span>
        <h1>Create your account</h1>
        <p className="muted">Join the FoodShare community.</p>

        <div className="form-grid">
          <div>
            <label>Name</label>
            <input required value={form.name} onChange={e => update('name', e.target.value)} />
          </div>
          <div>
            <label>Email</label>
            <input type="email" required value={form.email} onChange={e => update('email', e.target.value)} />
          </div>
          <div>
            <label>Password</label>
            <input type="password" required value={form.password} onChange={e => update('password', e.target.value)} />
          </div>
          <div>
            <label>Phone</label>
            <input required value={form.phone} onChange={e => update('phone', e.target.value)} />
          </div>
          <div>
            <label>City</label>
            <input required value={form.city} onChange={e => update('city', e.target.value)} />
          </div>
          <div>
            <label>Role</label>
            <select value={form.role} onChange={e => update('role', e.target.value)}>
              <option value="DONOR">Donor</option>
              <option value="NGO">NGO</option>
            </select>
          </div>
        </div>

        {message && <div className="alert success">{message}</div>}
        <button className="btn btn-primary full">Register</button>
        <p className="auth-footer">Already registered? <Link to="/login">Login</Link></p>
      </form>
    </div>
  )
}
