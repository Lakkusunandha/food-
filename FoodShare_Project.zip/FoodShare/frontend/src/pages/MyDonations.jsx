import { useEffect, useState } from 'react'
import API from '../api'

const demo = [
  { id: 1, foodType: 'Biryani', quantity: 20, unit: 'KG', location: 'ABC Restaurant', city: 'Vijayawada', status: 'AVAILABLE' },
  { id: 2, foodType: 'Rice', quantity: 15, unit: 'KG', location: 'ABC Restaurant', city: 'Vijayawada', status: 'CLAIMED' },
  { id: 3, foodType: 'Meals', quantity: 50, unit: 'PLATES', location: 'ABC Restaurant', city: 'Vijayawada', status: 'COMPLETED' }
]

export default function MyDonations() {
  const [items, setItems] = useState(demo)
  const user = JSON.parse(localStorage.getItem('foodshareUser') || '{"id":1}')

  useEffect(() => {
    API.get(`/donations/donor/${user.id || 1}`)
      .then(res => setItems(res.data))
      .catch(() => {})
  }, [user.id])

  return (
    <div className="container">
      <div className="page-heading">
        <span className="eyebrow">DONOR PORTAL</span>
        <h1>My Donations</h1>
      </div>
      <div className="table-card">
        <div className="table-scroll">
          <table>
            <thead><tr><th>Food</th><th>Qty</th><th>Location</th><th>Status</th></tr></thead>
            <tbody>
              {items.map(item => (
                <tr key={item.id}>
                  <td>{item.foodType}</td>
                  <td>{item.quantity} {item.unit}</td>
                  <td>{item.city}</td>
                  <td><span className={`status ${item.status.toLowerCase()}`}>{item.status}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
