import { Link } from 'react-router-dom'
import StatCard from '../components/StatCard'

const donations = [
  { foodType: 'Biryani', quantity: 20, unit: 'KG', status: 'AVAILABLE' },
  { foodType: 'Rice', quantity: 15, unit: 'KG', status: 'CLAIMED' },
  { foodType: 'Meals', quantity: 50, unit: 'PLATES', status: 'COMPLETED' }
]

export default function DonorDashboard() {
  const user = JSON.parse(localStorage.getItem('foodshareUser') || '{}')

  return (
    <div className="container">
      <div className="dashboard-header">
        <div>
          <span className="eyebrow">DONOR PORTAL</span>
          <h1>Welcome, {user.name || 'ABC Restaurant'} 👋</h1>
          <p className="muted">Manage your surplus food donations.</p>
        </div>
        <Link className="btn btn-primary" to="/post-donation">＋ Post Food Donation</Link>
      </div>

      <div className="stats-grid">
        <StatCard icon="🍱" label="My Donations" value="12" />
        <StatCard icon="🟢" label="Available" value="5" />
        <StatCard icon="🤝" label="Claimed" value="3" />
        <StatCard icon="✅" label="Completed" value="4" />
      </div>

      <section className="table-card">
        <div className="section-title-row"><h2>Recent Donations</h2><Link to="/my-donations">View all →</Link></div>
        <div className="table-scroll">
          <table>
            <thead><tr><th>Food</th><th>Quantity</th><th>Status</th></tr></thead>
            <tbody>
              {donations.map((d, i) => (
                <tr key={i}>
                  <td>{d.foodType}</td><td>{d.quantity} {d.unit}</td>
                  <td><span className={`status ${d.status.toLowerCase()}`}>{d.status}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  )
}
