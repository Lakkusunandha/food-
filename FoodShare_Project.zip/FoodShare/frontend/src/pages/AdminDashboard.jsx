import { useEffect, useState } from 'react'
import StatCard from '../components/StatCard'
import API from '../api'

export default function AdminDashboard() {
  const [stats, setStats] = useState({
    totalUsers: 120, totalDonations: 85, availableDonations: 20,
    claimedDonations: 35, completedDonations: 30
  })
  const [activity, setActivity] = useState([
    { actor: 'ABC Restaurant', action: 'posted 20 KG Biryani' },
    { actor: 'Helping Hands NGO', action: 'claimed 20 KG Biryani' }
  ])

  useEffect(() => {
    API.get('/admin/stats').then(res => setStats(res.data)).catch(() => {})
    API.get('/admin/activity').then(res => setActivity(res.data)).catch(() => {})
  }, [])

  return (
    <div className="container">
      <div className="page-heading">
        <span className="eyebrow">ADMIN PORTAL</span>
        <h1>Admin Dashboard</h1>
        <p className="muted">Monitor FoodShare platform activity and impact.</p>
      </div>

      <div className="stats-grid five">
        <StatCard icon="👥" label="Total Users" value={stats.totalUsers} />
        <StatCard icon="🍱" label="Total Donations" value={stats.totalDonations} />
        <StatCard icon="🟢" label="Available" value={stats.availableDonations} />
        <StatCard icon="🤝" label="Claimed" value={stats.claimedDonations} />
        <StatCard icon="✅" label="Completed" value={stats.completedDonations} />
      </div>

      <section className="activity-card">
        <h2>Recent Activity</h2>
        {activity.map((a, i) => (
          <div className="activity-row" key={i}>
            <span className="activity-dot">●</span>
            <p><strong>{a.actor}</strong> {a.action}</p>
          </div>
        ))}
      </section>
    </div>
  )
}
