import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import API from '../api'

export default function PostDonation() {
  const navigate = useNavigate()
  const user = JSON.parse(localStorage.getItem('foodshareUser') || '{"id":1,"name":"ABC Restaurant"}')
  const [form, setForm] = useState({
    foodType: '', quantity: '', unit: 'KG', location: user.name || '',
    city: '', pickupTime: '', description: ''
  })
  const [message, setMessage] = useState('')

  const update = (key, value) => setForm({ ...form, [key]: value })

  const submit = async (e) => {
    e.preventDefault()
    const payload = { ...form, donorId: user.id || 1, quantity: Number(form.quantity), status: 'AVAILABLE' }

    try {
      await API.post('/donations', payload)
      setMessage('Donation posted successfully!')
      setTimeout(() => navigate('/my-donations'), 700)
    } catch {
      setMessage('Donation ready for submission. Start Spring Boot to persist it.')
    }
  }

  return (
    <div className="container narrow">
      <div className="page-heading">
        <span className="eyebrow">DONATE SURPLUS FOOD</span>
        <h1>Post Surplus Food</h1>
        <p className="muted">Give NGOs enough information to arrange a safe pickup.</p>
      </div>

      <form className="form-card" onSubmit={submit}>
        <div className="form-grid">
          <div><label>Food Type</label><input required placeholder="e.g. Biryani" value={form.foodType} onChange={e => update('foodType', e.target.value)} /></div>
          <div><label>Quantity</label><input required type="number" min="1" value={form.quantity} onChange={e => update('quantity', e.target.value)} /></div>
          <div><label>Unit</label><select value={form.unit} onChange={e => update('unit', e.target.value)}><option>KG</option><option>PLATES</option><option>PACKETS</option><option>PORTIONS</option></select></div>
          <div><label>Location</label><input required value={form.location} onChange={e => update('location', e.target.value)} /></div>
          <div><label>City</label><input required placeholder="Vijayawada" value={form.city} onChange={e => update('city', e.target.value)} /></div>
          <div><label>Pickup Time</label><input required type="time" value={form.pickupTime} onChange={e => update('pickupTime', e.target.value)} /></div>
        </div>
        <label>Description</label>
        <textarea rows="4" placeholder="Freshly prepared food..." value={form.description} onChange={e => update('description', e.target.value)} />
        {message && <div className="alert success">{message}</div>}
        <button className="btn btn-primary">Post Donation</button>
      </form>
    </div>
  )
}
