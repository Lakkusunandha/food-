import { useEffect, useState } from 'react'
import DonationCard from '../components/DonationCard'
import API from '../api'

const demo = [
  { id: 1, foodType: 'Biryani', quantity: 20, unit: 'KG', location: 'ABC Restaurant', city: 'Vijayawada', pickupTime: '06:00 PM', description: 'Freshly prepared food.', status: 'AVAILABLE' },
  { id: 2, foodType: 'Rice Meals', quantity: 30, unit: 'PLATES', location: 'Community Kitchen', city: 'Vijayawada', pickupTime: '07:00 PM', description: 'Packed meals ready for pickup.', status: 'AVAILABLE' }
]

export default function AvailableDonations() {
  const [donations, setDonations] = useState(demo)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    API.get('/donations/available')
      .then(res => setDonations(res.data))
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [])

  const claim = async (donation) => {
    const user = JSON.parse(localStorage.getItem('foodshareUser') || '{"id":2}')
    try {
      await API.post('/claims', { donationId: donation.id, ngoId: user.id || 2 })
    } catch {}
    setDonations(prev => prev.map(d => d.id === donation.id ? { ...d, status: 'CLAIMED' } : d))
    alert(`${donation.foodType} claimed successfully!`)
  }

  return (
    <div className="container">
      <div className="page-heading">
        <span className="eyebrow">NGO PORTAL</span>
        <h1>Available Donations</h1>
        <p className="muted">Find surplus food available for pickup in your community.</p>
      </div>
      {loading && <p>Loading...</p>}
      <div className="cards-grid">
        {donations.filter(d => d.status === 'AVAILABLE').map(d => (
          <DonationCard key={d.id} donation={d} onClaim={claim} />
        ))}
      </div>
      {!donations.some(d => d.status === 'AVAILABLE') && <div className="empty-state">No available donations right now.</div>}
    </div>
  )
}
