import { useEffect, useState } from 'react'
import API from '../api'

const demo = [
  { id: 1, donation: { foodType: 'Biryani', quantity: 20, unit: 'KG', location: 'ABC Restaurant', city: 'Vijayawada' }, status: 'CLAIMED' }
]

export default function MyClaims() {
  const [claims, setClaims] = useState(demo)
  const user = JSON.parse(localStorage.getItem('foodshareUser') || '{"id":2}')

  useEffect(() => {
    API.get(`/claims/ngo/${user.id || 2}`)
      .then(res => setClaims(res.data))
      .catch(() => {})
  }, [user.id])

  const updateStatus = async (claim, next) => {
    try {
      await API.put(`/donations/${claim.donation.id}/status`, { status: next })
    } catch {}
    setClaims(prev => prev.map(c => c.id === claim.id ? { ...c, status: next } : c))
  }

  return (
    <div className="container">
      <div className="page-heading">
        <span className="eyebrow">NGO PORTAL</span>
        <h1>My Claimed Food</h1>
      </div>
      <div className="cards-grid">
        {claims.map(claim => (
          <article className="donation-card" key={claim.id}>
            <div className="card-top">
              <div><span className="food-emoji">🍛</span><h3>{claim.donation?.foodType || 'Food Donation'}</h3></div>
              <span className={`status ${claim.status.toLowerCase()}`}>{claim.status}</span>
            </div>
            <div className="donation-quantity">{claim.donation?.quantity} {claim.donation?.unit}</div>
            <div className="card-details">
              <p>🏪 {claim.donation?.location}</p>
              <p>📍 {claim.donation?.city}</p>
            </div>
            {claim.status === 'CLAIMED' && <button className="btn btn-primary full" onClick={() => updateStatus(claim, 'PICKED_UP')}>Mark as Picked Up</button>}
            {claim.status === 'PICKED_UP' && <button className="btn btn-primary full" onClick={() => updateStatus(claim, 'COMPLETED')}>Mark Completed</button>}
          </article>
        ))}
      </div>
    </div>
  )
}
