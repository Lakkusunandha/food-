import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import API from '../api'

export default function Login() {
  const [form, setForm] = useState({ email: '', password: '' })
  const [error, setError] = useState('')
  const navigate = useNavigate()

  const submit = async (e) => {
    e.preventDefault()
    setError('')

    try {
      const response = await API.post('/auth/login', form)
      const user = response.data
      localStorage.setItem('foodshareUser', JSON.stringify(user))
      redirect(user.role)
    } catch {
      // Demo mode so judges can test the complete frontend before backend auth is connected.
      const demo = {
        'donor@foodshare.com': { id: 1, name: 'ABC Restaurant', role: 'DONOR', email: form.email },
        'ngo@foodshare.com': { id: 2, name: 'Helping Hands NGO', role: 'NGO', email: form.email },
        'admin@foodshare.com': { id: 3, name: 'FoodShare Admin', role: 'ADMIN', email: form.email }
      }[form.email.toLowerCase()]

      if (demo) {
        localStorage.setItem('foodshareUser', JSON.stringify(demo))
        redirect(demo.role)
      } else {
        setError('Login failed. Try donor@foodshare.com, ngo@foodshare.com, or admin@foodshare.com for demo mode.')
      }
    }
  }

  const redirect = (role) => {
    if (role === 'DONOR') navigate('/donor')
    else if (role === 'NGO') navigate('/donations')
    else navigate('/admin')
  }

  return (
    <div className="auth-wrap">
      <form className="auth-card" onSubmit={submit}>
        <span className="auth-icon">🔐</span>
        <h1>FoodShare Login</h1>
        <p className="muted">Access your FoodShare account.</p>

        <label>Email</label>
        <input type="email" required value={form.email}
          onChange={e => setForm({ ...form, email: e.target.value })} />

        <label>Password</label>
        <input type="password" required value={form.password}
          onChange={e => setForm({ ...form, password: e.target.value })} />

        {error && <div className="alert error">{error}</div>}

        <button className="btn btn-primary full">Login</button>

        <div className="demo-hint">
          Demo: donor@foodshare.com / any password<br />
          NGO: ngo@foodshare.com / any password<br />
          Admin: admin@foodshare.com / any password
        </div>

        <p className="auth-footer">Don't have an account? <Link to="/register">Register</Link></p>
      </form>
    </div>
  )
}
