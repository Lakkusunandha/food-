import { Link, useLocation, useNavigate } from 'react-router-dom'

export default function Navbar() {
  const location = useLocation()
  const navigate = useNavigate()
  const user = JSON.parse(localStorage.getItem('foodshareUser') || 'null')

  const logout = () => {
    localStorage.removeItem('foodshareUser')
    navigate('/')
  }

  return (
    <header className="navbar">
      <Link to="/" className="brand">
        <span className="brand-icon">🍱</span>
        FoodShare
      </Link>

      <nav className="nav-links">
        <Link className={location.pathname === '/' ? 'active' : ''} to="/">Home</Link>
        <Link to="/donations">Available Food</Link>
        {user?.role === 'DONOR' && (
          <>
            <Link to="/donor">Donor Dashboard</Link>
            <Link to="/my-donations">My Donations</Link>
          </>
        )}
        {user?.role === 'NGO' && <Link to="/my-claims">My Claims</Link>}
        {user?.role === 'ADMIN' && <Link to="/admin">Admin Dashboard</Link>}
      </nav>

      <div className="nav-actions">
        {!user ? (
          <>
            <Link className="btn btn-outline small" to="/login">Login</Link>
            <Link className="btn btn-primary small" to="/register">Register</Link>
          </>
        ) : (
          <>
            <span className="role-pill">{user.role}</span>
            <button className="btn btn-dark small" onClick={logout}>Logout</button>
          </>
        )}
      </div>
    </header>
  )
}
