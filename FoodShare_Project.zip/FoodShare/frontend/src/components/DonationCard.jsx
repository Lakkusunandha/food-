export default function DonationCard({ donation, onClaim }) {
  const status = donation.status || 'AVAILABLE'

  return (
    <article className="donation-card">
      <div className="card-top">
        <div>
          <span className="food-emoji">🍛</span>
          <h3>{donation.foodType}</h3>
        </div>
        <span className={`status ${status.toLowerCase()}`}>{status}</span>
      </div>

      <div className="donation-quantity">
        {donation.quantity} {donation.unit}
      </div>

      <div className="card-details">
        <p>📍 {donation.location}, {donation.city}</p>
        <p>⏰ Pickup: {donation.pickupTime}</p>
        {donation.description && <p>📝 {donation.description}</p>}
      </div>

      {status === 'AVAILABLE' && onClaim && (
        <button className="btn btn-primary full" onClick={() => onClaim(donation)}>
          CLAIM FOOD
        </button>
      )}
    </article>
  )
}
