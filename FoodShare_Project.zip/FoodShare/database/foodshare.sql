CREATE DATABASE IF NOT EXISTS foodshare;
USE foodshare;

-- Spring Boot/JPA will create/update tables automatically.
-- This script is useful for creating the database before starting the backend.

-- Optional manual schema reference:
CREATE TABLE IF NOT EXISTS users (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(150) NOT NULL,
    email VARCHAR(180) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(30),
    city VARCHAR(100),
    role VARCHAR(20) NOT NULL
);

CREATE TABLE IF NOT EXISTS donations (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    food_type VARCHAR(150) NOT NULL,
    quantity DOUBLE NOT NULL,
    unit VARCHAR(30) NOT NULL,
    location VARCHAR(200) NOT NULL,
    city VARCHAR(100) NOT NULL,
    pickup_time VARCHAR(50) NOT NULL,
    description TEXT,
    status VARCHAR(30) NOT NULL,
    donor_id BIGINT NOT NULL,
    CONSTRAINT fk_donation_donor FOREIGN KEY (donor_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS claims (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    donation_id BIGINT NOT NULL,
    ngo_id BIGINT NOT NULL,
    claimed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_claim_donation FOREIGN KEY (donation_id) REFERENCES donations(id),
    CONSTRAINT fk_claim_ngo FOREIGN KEY (ngo_id) REFERENCES users(id)
);
