# FoodShare — Food Donation & Redistribution Platform

FoodShare connects food donors (restaurants, hotels, individuals) with NGOs/community organizations that can claim surplus food.

## Architecture

React + Vite
    ↓ Axios
Spring Boot REST API
    ↓
Controller → Service → Repository
    ↓
MySQL

## Main demo flow

DONOR:
Register → Login → Donor Dashboard → Post Donation → My Donations

NGO:
Login → Available Donations → Claim Food → My Claims → Picked Up → Completed

ADMIN:
Login → Admin Dashboard → View platform statistics/activity

## Requirements

- Node.js LTS + npm
- Java 17+
- Maven 3.9+ (or Maven Wrapper if you add one)
- MySQL 8+
- VS Code / IntelliJ IDEA / Eclipse

## 1. MySQL setup

Create a database:

CREATE DATABASE foodshare;

The Spring Boot backend uses:
- host: localhost
- port: 3306
- database: foodshare
- username: root
- password: root

Change the credentials in:
backend/src/main/resources/application.properties

## 2. Run backend

cd backend
mvn spring-boot:run

Backend:
http://localhost:8080

## 3. Run frontend

cd frontend
npm install
npm run dev

Frontend:
http://localhost:5173

## Demo accounts

The frontend includes demo-login behavior so the UI can be tested without a working authentication backend:

donor@foodshare.com
ngo@foodshare.com
admin@foodshare.com

Any password works in demo mode.

When the backend authentication is implemented, replace the demo behavior in Login.jsx with the real /api/auth/login call.

## Important API endpoints

Auth:
POST /api/auth/register
POST /api/auth/login

Donations:
GET    /api/donations
GET    /api/donations/available
GET    /api/donations/donor/{donorId}
POST   /api/donations
PUT    /api/donations/{id}/status

Claims:
GET  /api/claims/ngo/{ngoId}
POST /api/claims

Admin:
GET /api/admin/stats
GET /api/admin/activity

## Notes

This is a hackathon/academic MVP. Authentication is intentionally simple and should be upgraded to JWT + password hashing before production use.
