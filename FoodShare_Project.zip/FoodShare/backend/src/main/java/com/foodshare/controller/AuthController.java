package com.foodshare.controller;

import com.foodshare.dto.LoginRequest;
import com.foodshare.dto.RegisterRequest;
import com.foodshare.model.User;
import com.foodshare.repository.UserRepository;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "http://localhost:5173")
public class AuthController {
    private final UserRepository users;

    public AuthController(UserRepository users) {
        this.users = users;
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody RegisterRequest request) {
        if (users.findByEmail(request.email()).isPresent()) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(Map.of("message", "Email already registered"));
        }

        User user = new User();
        user.setName(request.name());
        user.setEmail(request.email());
        user.setPassword(request.password()); // Hackathon MVP; use BCrypt in production.
        user.setPhone(request.phone());
        user.setCity(request.city());
        user.setRole(request.role());

        User saved = users.save(user);
        saved.setPassword(null);
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest request) {
        return users.findByEmail(request.email())
            .filter(u -> u.getPassword().equals(request.password()))
            .map(u -> {
                u.setPassword(null);
                return ResponseEntity.ok(u);
            })
            .orElseGet(() -> ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body(Map.of("message", "Invalid email or password")));
    }
}
