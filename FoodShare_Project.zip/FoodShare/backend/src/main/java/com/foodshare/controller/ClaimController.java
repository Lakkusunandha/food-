package com.foodshare.controller;

import com.foodshare.dto.ClaimRequest;
import com.foodshare.model.Claim;
import com.foodshare.model.Donation;
import com.foodshare.model.User;
import com.foodshare.repository.ClaimRepository;
import com.foodshare.repository.DonationRepository;
import com.foodshare.repository.UserRepository;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/claims")
@CrossOrigin(origins = "http://localhost:5173")
public class ClaimController {
    private final ClaimRepository claims;
    private final DonationRepository donations;
    private final UserRepository users;

    public ClaimController(ClaimRepository claims, DonationRepository donations, UserRepository users) {
        this.claims = claims;
        this.donations = donations;
        this.users = users;
    }

    @GetMapping("/ngo/{ngoId}")
    public List<Claim> byNgo(@PathVariable Long ngoId) {
        return claims.findByNgoId(ngoId);
    }

    @PostMapping
    public ResponseEntity<?> create(@RequestBody ClaimRequest request) {
        Donation donation = donations.findById(request.donationId())
            .orElseThrow(() -> new RuntimeException("Donation not found"));
        User ngo = users.findById(request.ngoId())
            .orElseThrow(() -> new RuntimeException("NGO not found"));

        if (donation.getStatus() != Donation.Status.AVAILABLE) {
            return ResponseEntity.badRequest().body(Map.of("message", "Donation is no longer available"));
        }
        if (claims.existsByDonationId(donation.getId())) {
            return ResponseEntity.badRequest().body(Map.of("message", "Donation already claimed"));
        }

        Claim claim = new Claim();
        claim.setDonation(donation);
        claim.setNgo(ngo);
        donation.setStatus(Donation.Status.CLAIMED);

        donations.save(donation);
        return ResponseEntity.status(HttpStatus.CREATED).body(claims.save(claim));
    }
}
