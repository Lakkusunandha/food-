package com.foodshare.repository;

import com.foodshare.model.Claim;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ClaimRepository extends JpaRepository<Claim, Long> {
    List<Claim> findByNgoId(Long ngoId);
    boolean existsByDonationId(Long donationId);
}
