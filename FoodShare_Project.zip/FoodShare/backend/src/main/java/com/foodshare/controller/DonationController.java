package com.foodshare.controller;

import com.foodshare.model.Donation;
import com.foodshare.model.User;
import com.foodshare.repository.DonationRepository;
import com.foodshare.repository.UserRepository;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/donations")
@CrossOrigin(origins = "http://localhost:5173")
public class DonationController {
    private final DonationRepository donations;
    private final UserRepository users;

    public DonationController(DonationRepository donations, UserRepository users) {
        this.donations = donations;
        this.users = users;
    }

    @GetMapping
    public List<Donation> all() {
        return donations.findAll();
    }

    @GetMapping("/available")
    public List<Donation> available() {
        return donations.findByStatus(Donation.Status.AVAILABLE);
    }

    @GetMapping("/donor/{donorId}")
    public List<Donation> byDonor(@PathVariable Long donorId) {
        return donations.findByDonorId(donorId);
    }

    @PostMapping
    public ResponseEntity<?> create(@RequestBody Donation donation) {
        if (donation.getDonor() == null || donation.getDonor().getId() == null) {
            return ResponseEntity.badRequest().body(Map.of("message", "donorId is required"));
        }

        User donor = users.findById(donation.getDonor().getId())
            .orElseThrow(() -> new RuntimeException("Donor not found"));
        donation.setDonor(donor);
        donation.setStatus(Donation.Status.AVAILABLE);

        return ResponseEntity.status(HttpStatus.CREATED).body(donations.save(donation));
    }

    @PutMapping("/{id}/status")
    public ResponseEntity<?> updateStatus(@PathVariable Long id, @RequestBody Map<String, String> body) {
        Donation donation = donations.findById(id)
            .orElseThrow(() -> new RuntimeException("Donation not found"));

        donation.setStatus(Donation.Status.valueOf(body.get("status")));
        return ResponseEntity.ok(donations.save(donation));
    }
}
