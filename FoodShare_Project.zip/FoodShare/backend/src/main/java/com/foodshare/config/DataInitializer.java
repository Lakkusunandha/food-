package com.foodshare.config;

import com.foodshare.model.User;
import com.foodshare.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DataInitializer {

    @Bean
    CommandLineRunner seedUsers(UserRepository users) {
        return args -> {
            if (users.findByEmail("donor@foodshare.com").isEmpty()) {
                User donor = new User();
                donor.setName("ABC Restaurant");
                donor.setEmail("donor@foodshare.com");
                donor.setPassword("demo");
                donor.setPhone("9876543210");
                donor.setCity("Vijayawada");
                donor.setRole(User.Role.DONOR);
                users.save(donor);
            }

            if (users.findByEmail("ngo@foodshare.com").isEmpty()) {
                User ngo = new User();
                ngo.setName("Helping Hands NGO");
                ngo.setEmail("ngo@foodshare.com");
                ngo.setPassword("demo");
                ngo.setPhone("9876543211");
                ngo.setCity("Vijayawada");
                ngo.setRole(User.Role.NGO);
                users.save(ngo);
            }

            if (users.findByEmail("admin@foodshare.com").isEmpty()) {
                User admin = new User();
                admin.setName("FoodShare Admin");
                admin.setEmail("admin@foodshare.com");
                admin.setPassword("demo");
                admin.setPhone("9876543212");
                admin.setCity("Vijayawada");
                admin.setRole(User.Role.ADMIN);
                users.save(admin);
            }
        };
    }
}
