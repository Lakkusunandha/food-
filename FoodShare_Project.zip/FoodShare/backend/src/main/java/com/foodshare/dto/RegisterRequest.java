package com.foodshare.dto;

import com.foodshare.model.User;

public record RegisterRequest(
    String name, String email, String password,
    String phone, String city, User.Role role
) {}
