package com.foodshare.repository;

import com.foodshare.model.Donation;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface DonationRepository extends JpaRepository<Donation, Long> {
    List<Donation> findByStatus(Donation.Status status);
    List<Donation> findByDonorId(Long donorId);
}
