package com.foodshare.controller;

import com.foodshare.model.Donation;
import com.foodshare.model.User;
import com.foodshare.repository.DonationRepository;
import com.foodshare.repository.UserRepository;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = "http://localhost:5173")
public class AdminController {
    private final UserRepository users;
    private final DonationRepository donations;

    public AdminController(UserRepository users, DonationRepository donations) {
        this.users = users;
        this.donations = donations;
    }

    @GetMapping("/stats")
    public Map<String, Long> stats() {
        return Map.of(
            "totalUsers", users.count(),
            "totalDonations", donations.count(),
            "availableDonations", donations.findByStatus(Donation.Status.AVAILABLE).size(),
            "claimedDonations", donations.findByStatus(Donation.Status.CLAIMED).size(),
            "completedDonations", donations.findByStatus(Donation.Status.COMPLETED).size()
        );
    }

    @GetMapping("/activity")
    public List<Map<String, String>> activity() {
        List<Donation> recent = donations.findAll();
        Collections.reverse(recent);

        List<Map<String, String>> result = new ArrayList<>();
        recent.stream().limit(10).forEach(d ->
            result.add(Map.of(
                "actor", d.getDonor().getName(),
                "action", "posted " + d.getQuantity() + " " + d.getUnit() + " " + d.getFoodType()
            ))
        );
        return result;
    }
}
