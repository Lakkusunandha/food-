package com.foodshare.dto;

public record LoginRequest(String email, String password) {}
