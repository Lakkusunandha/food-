package com.foodshare.dto;

public record ClaimRequest(Long donationId, Long ngoId) {}
