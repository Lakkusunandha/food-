package com.foodshare.dto;

import com.foodshare.model.Donation;

public record StatusRequest(Donation.Status status) {}
